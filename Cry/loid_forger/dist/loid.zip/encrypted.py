from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes

with open('loid_key.pem', 'r') as f:
    key_data = f.read()
    
private_key = RSA.import_key(key_data)
public_key = private_key.publickey()

with open('encrypted.png', 'rb') as spy:
    to_encrypt = spy.read()
    
cipher_encrypt = PKCS1_OAEP.new(public_key)
cipher_decrypt = PKCS1_OAEP.new(private_key)

key_size = public_key.size_in_bytes()
max_chunk_size = key_size - 42  

encrypted_data = b""
for i in range(0, len(to_encrypt), max_chunk_size):
    chunk = to_encrypt[i:i + max_chunk_size]
    encrypted_data += cipher_encrypt.encrypt(chunk)

with open('encrypted', 'wb') as mes:
    mes.write(encrypted_data)
