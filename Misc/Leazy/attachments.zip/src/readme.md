# Whangsaf Bot Open Source le
Bot ini opensource silahkan di pakai. beberapa command seperti `virtex`, `bug whatsapp` saya jadikan kusus premium aja biar gak di salah gunakan, jika ingin bisa contact saya.

### Require
- Node 20.x
- ffmpeg

### Install
```bash
git clone https://github.com/ilsyaa/lazy-whatsapp-bot
```
```bash
cd lazy-whatsapp-bot
```
```bash
npm install
```
### Run BOT
```bash
npm run start
```

### Development
```bash
npm run dev
```
