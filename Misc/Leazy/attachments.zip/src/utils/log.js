const Logger = require("@ptkdev/logger")
const log = new Logger()

module.exports = log