const { ttdl } = require('./ruhend-scrapper/tiktok.js');
const { fbdl } = require('./ruhend-scrapper/facebook.js');
module.exports = { ttdl, fbdl }