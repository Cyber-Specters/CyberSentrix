# Title

'Flexo'

# Description

'Bantu saya jualan yukk, saya jual beraneka ragam barang di website ini, namun website jualan saya berhasil diretas dengan memanfaatkan salah satu celah kerentanan.

Bantu saya mendapatkan celah kerentanan tersebut.'

# Author

'zfernm'

# Flag 

`TechnoFair11{easyy_Chall_web_Exploit_Flexo}`