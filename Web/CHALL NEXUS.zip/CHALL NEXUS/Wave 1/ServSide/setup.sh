#!/bin/bash

declare CONTAINER_NAME="absen"

declare -i EXPOSED_PORT=5100

declare -i PUBLIC_PORT=2911

docker stop $CONTAINER_NAME
docker rm $CONTAINER_NAME
docker image rm $CONTAINER_NAME
docker build -t $CONTAINER_NAME .
docker run -d -p $PUBLIC_PORT:$EXPOSED_PORT --rm --name $CONTAINER_NAME $CONTAINER_NAME
