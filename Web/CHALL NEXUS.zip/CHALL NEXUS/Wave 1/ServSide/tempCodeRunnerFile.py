# Data yang akan dikirim dalam permintaan POST
data = {
    'la24': payload
}