jangan lupa .env.example cp ke .env biasa
pake air, buat hot reload
air-golang
migrate-golang 

ini tools cocok buat development